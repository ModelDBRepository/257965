# Rangamani-Calcium2019
COMSOL files that accompany Bell et al. 2019 in JGP.

COMSOL is a commercially available software and is required to open these files. For model details, please see Bell et al. 2019 in JGP. COMSOL file results have been cleared due to file size constraints.
